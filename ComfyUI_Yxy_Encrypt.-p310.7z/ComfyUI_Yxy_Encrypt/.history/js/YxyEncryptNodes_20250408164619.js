import { app } from "/scripts/app.js";
import { GroupNodeHandler } from "/extensions/core/groupNode.js";
import { api } from "/scripts/api.js";
import { $el } from "../../../scripts/ui.js";

async function encipher (hiddenJson, tempJson, password) {
  try {
    const workflowName = document.title;
    let appNodes = null;
    if (app.graph.nodes) {
      appNodes = app.graph.nodes;
    } else {
      appNodes = app.graph._nodes;
    }
    const nodes = appNodes.filter(node => node.type === "YxyEncryptNodes");
    const nonceStr = nodes.length > 0 ? nodes[0].properties['hiddenJson'] : '';
    const flowCode = nodes.length > 0 ? nodes[0].properties['flowCode'] : '';
    const response = await api.fetchApi("/yxy/encipher", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ "hiddenJson": hiddenJson, 'tempJson': tempJson, 'password': password, 'nonceStr': nonceStr, 'workflowName': workflowName, 'flowCode': flowCode }),
    });
    if (response.status === 200) {
      let text = await response.text();
      let data = JSON.parse(text);
      return data;
    }
    throw new Error(response.statusText);
  } catch (error) {
    console.error(error);
  }
}

async function appkey (password) {
  try {
    const response = await api.fetchApi("/yxy/appkey", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ 'password': password }),
    });
    if (response.status === 200) {
      let text = await response.text();
      let data = JSON.parse(text);
      return data;
    }
    throw new Error(response.statusText);
  } catch (error) {
    console.error(error);
  }
}

app.registerExtension({
  name: "Comfy.yxy.YxyEncryptNodes",
  async beforeRegisterNodeDef (nodeType, nodeData, app) {
    if (nodeData.name !== "YxyEncryptNodes") {
      return;
    }
    const onNodeCreated = nodeType.prototype.onNodeCreated;
    nodeType.prototype.onNodeCreated = function () {
      const result = onNodeCreated ? onNodeCreated.apply(this, arguments) : undefined;
      this.setProperty("hiddenJson", '');
      this.setProperty("flowCode", '');
      this.setProperty("flowContentCode", '');
      let inputType = "text";
      if (app.graph._nodes) {
        inputType = "list";
      }
      const hiddenJson = this.widgets.find(w => w.name === "hiddenJson");
      const flowCode = this.widgets.find(w => w.name === "flowCode");
      const flowContentCode = this.widgets.find(w => w.name === "flowContentCode");
      if (app.graph._nodes) {
        hiddenJson.type = "list";
        flowCode.type = "list";
        flowContentCode.type = "list";
      }
      Object.defineProperty(hiddenJson, "value", {
        set: async (v) => { },
        get: () => {
          return this.properties['hiddenJson'];
        }
      });
      Object.defineProperty(flowCode, "value", {
        set: async (v) => { },
        get: () => {
          return this.properties['flowCode'];
        }
      });
      Object.defineProperty(flowContentCode, "value", {
        set: async (v) => { },
        get: () => {
          return this.properties['flowContentCode'];
        }
      });
      return result;
    }
  }
});

function traceNodeConnections (connections, startId, endId) {
  const adjacency = {};
  for (const conn of connections) {
    const [_, src, __, dest] = conn;
    if (!adjacency[src]) adjacency[src] = [];
    adjacency[src].push(dest);
  }
  const visited = new Set();
  const queue = [startId];
  while (queue.length > 0) {
    const current = queue.shift();
    if (visited.has(current)) continue;
    visited.add(current);
    if (current === endId) continue;
    const neighbors = adjacency[current] || [];
    neighbors.forEach(n => {
      if (!visited.has(n)) queue.push(n);
    });
  }
  return Array.from(visited);
}

function addConvertToGroupOptions () {
  function addOption (options, index) {
    const selected = Object.values(app.canvas.selected_nodes ?? {});
    const disabled = selected.length < 2 || selected.find((n) => GroupNodeHandler.isGroupNode(n) || n.type == "YxyEncryptNodes");
    let tempJson = "";
    let nodeName = "加密节点-yxy";
    options.splice(index + 1, null, {
      content: nodeName,
      disabled,
      callback: async () => {
        let comfyApp = null;
        if (window.comfyAPI) {
          comfyApp = window.comfyAPI.app.app;
        } else {
          comfyApp = window.app;
        }
        let appNodes = null;
        if (app.graph.nodes) {
          appNodes = app.graph.nodes;
        } else {
          appNodes = app.graph._nodes;
        }
        let comfyAppObj = null;
        await comfyApp.graphToPrompt().then((result) => {
          comfyAppObj = result;
        })

        const connections = comfyAppObj.workflow.links;
        const loopstarts = appNodes.filter(node => node.type === "easy forLoopStart");
        const loopends = appNodes.filter(node => node.type === "easy forLoopEnd");
        const loopstart = loopstarts && loopstarts[0] ? loopstarts[0].id : null;
        const loopend = loopends && loopends[0] ? loopends[0].id : null;
        if (loopstart) {
          const result = traceNodeConnections(connections, loopstart, loopend);
          const banSelected = Object.values(app.canvas.selected_nodes ?? {}).map(o => { return o.id }).filter(item => result.includes(item));
          if (banSelected && banSelected.length > 0) {
            // alert("选中的节点不可加密")
            // return
          }
        }

        var userInput = prompt("请输入appKey:", "");
        if (null == userInput) {
          return;
        }
        if ("" === userInput) {
          alert("请输入appKey!");
          return;
        }
        const encryptStr = await appkey(userInput);
        if (!encryptStr.success) {
          alert("加密异常");
          return;
        }
        tempJson = JSON.stringify(comfyAppObj.workflow);
        const hiddenNodes = LiteGraph.createNode('YxyEncryptNodes');
        hiddenNodes.removeOutput(0);
        hiddenNodes.pos = selected[0].pos;
        app.graph.add(hiddenNodes);
        const idList = selected.map(w => {
          return '' + w.id; // 获取选择节点ID
        });

        comfyApp.graphToPrompt().then(async (p2) => {
          const output = JSON.parse(JSON.stringify(p2.output));
          let noutput = {};
          for (let key of Object.keys(output)) {
            if (idList.indexOf(key) >= 0) {
              noutput[key] = output[key];
            }
          }
          let inputOriginIds = {};
          for (let i = 0; i < selected.length; i++) {
            noutput['' + selected[i].id]['widgets_values'] = selected[i].widgets_values;
            noutput['' + selected[i].id]['pos'] = selected[i].pos;
            if ('inputs' in selected[i]) {
              for (let j = 0; j < selected[i].inputs.length; j++) {
                const link = selected[i].inputs[j].link;
                const name = selected[i].inputs[j].name;
                const type = selected[i].inputs[j].type;
                if (link) {
                  const node_IDA = selected[i].graph.links[link].origin_id;
                  if (idList.indexOf(node_IDA + '') < 0) {
                    const origin_slotA = selected[i].graph.links[link].origin_slot;
                    if ((node_IDA + ':' + origin_slotA) in inputOriginIds) {
                      noutput[selected[i].id]["inputs"][name] = ["hidden", inputOriginIds[(node_IDA + ':' + origin_slotA)]];
                    } else {
                      hiddenNodes.addInput(name + "_" + ('inputs' in hiddenNodes ? hiddenNodes.inputs.length : 0), type);
                      const nName = hiddenNodes.inputs[hiddenNodes.inputs.length - 1].name;
                      noutput[selected[i].id]["inputs"][name] = ["hidden", nName];
                      const connectedNodeA = selected[i].graph._nodes_by_id[node_IDA];
                      try {
                        connectedNodeA.connect(origin_slotA, hiddenNodes, hiddenNodes.inputs.length - 1);
                        selected[i].disconnectInput(j);
                      } catch (error) {
                        console.error(error);
                      }
                      inputOriginIds[(node_IDA + ':' + origin_slotA)] = nName;
                    }
                  }
                } else {
                  hiddenNodes.addInput(name + "_" + ('inputs' in hiddenNodes ? hiddenNodes.inputs.length : 0), type);
                  const nName = hiddenNodes.inputs[hiddenNodes.inputs.length - 1].name;
                  noutput[selected[i].id]["inputs"][name] = ["hidden", nName];
                }
              }
            }
            if ('outputs' in selected[i]) {
              noutput[selected[i].id]["outputs"] = [];
              for (let j = 0; j < selected[i].outputs.length; j++) {
                const linkAs = selected[i].outputs[j].links;
                const name = selected[i].outputs[j].name;
                const type = selected[i].outputs[j].type;
                let outInputNodes = [];
                if (linkAs && linkAs.length > 0) {
                  let isSel = false;
                  for (let linkA of linkAs) {
                    const node_IDB = selected[i].graph.links[linkA].target_id;
                    if (idList.indexOf(node_IDB + '') < 0) {
                      isSel = true;
                      const origin_slotB = selected[i].graph.links[linkA].target_slot;
                      const connectedNodeB = selected[i].graph._nodes_by_id[node_IDB];
                      outInputNodes.push([connectedNodeB, origin_slotB]);
                    }
                  }
                  if (isSel) {
                    hiddenNodes.addOutput(name + "_" + ('outputs' in hiddenNodes ? hiddenNodes.outputs.length : 0), type);
                    noutput[selected[i].id]["outputs"].push([hiddenNodes.outputs.length - 1, j]);
                    for (let oin of outInputNodes) {
                      if (oin[0]) {
                        oin[0].disconnectInput(oin[1]);
                        hiddenNodes.connect(hiddenNodes.outputs.length - 1, oin[0], oin[1]);
                      }
                    }
                  }
                } else {
                  hiddenNodes.addOutput(name + "_" + ('outputs' in hiddenNodes ? hiddenNodes.outputs.length : 0), type);
                  noutput[selected[i].id]["outputs"].push([hiddenNodes.outputs.length - 1, j]);
                }
              }
            }
          }
          const encryptStr = await encipher(JSON.stringify(noutput, null, 2), tempJson, userInput);
          if (!encryptStr.success) {
            alert("加密异常");
            return;
          }
          hiddenNodes.setProperty("hiddenJson", encryptStr.encryptText);
          hiddenNodes.setProperty("flowCode", encryptStr.flowCode);
          hiddenNodes.setProperty("flowContentCode", encryptStr.flowContentCode);

          for (let e = app.graph._nodes.length - 1; 0 <= e; e--) {
            var a = app.graph._nodes[e];
            if (idList.indexOf(a.id + '') >= 0) {
              app.graph._nodes[e].onRemoved && app.graph._nodes[e].onRemoved();
              app.graph._nodes.splice(e, 1);
            }
          }
        });
        return hiddenNodes;
      }
    });
  }
  const getNodeMenuOptions = LGraphCanvas.prototype.getNodeMenuOptions;
  LGraphCanvas.prototype.getNodeMenuOptions = function (node) {
    const options = getNodeMenuOptions.apply(this, arguments);
    if (!GroupNodeHandler.isGroupNode(node)) {
      if (node.type != 'YxyEncryptNodes') {
        const index = options.findIndex((o) => o?.content === "Outputs") + 1 || options.length - 1;
        addOption(options, index);
      }
    }
    return options;
  }
}

const id = "Yxy.YxyEncryptNodes";
const ext = {
  name: id,
  setup () {
    addConvertToGroupOptions();
  }
}
app.registerExtension(ext);