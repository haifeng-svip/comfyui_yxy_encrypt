import json
from server import PromptServer
from aiohttp import web
import platform
import os
import base64
import lzma
import requests
import traceback
from comfy_execution.graph_utils import GraphBuilder
import hashlib
import uuid

#service_host = "https://comfyui.aigc-top.cn/admin-api"
service_host = "http://127.0.0.1:81"

class AlwaysEqualProxy(str):
    def __eq__(self, _):
        return True

    def __ne__(self, _):
        return False

class AlwaysTupleZero(tuple):
    def __getitem__(self, _):
        return AlwaysEqualProxy(super().__getitem__(0))

def is_link(obj):
    if not isinstance(obj, list):
        return False
    if len(obj) != 2:
        return False
    if not isinstance(obj[0], str):
        return False
    if not isinstance(obj[1], int) and not isinstance(obj[1], float) and not isinstance(obj[1], str):
        return False
    return True

def generate_device_id():
    info = {
        "mac": ":".join(["{:02x}".format((uuid.getnode() >> ele) & 0xff) for ele in range(0, 2*6, 2)][::-1]),
        "cpu": platform.processor() + "-" + platform.node() + "-" + platform.system() + "-" + str(platform.architecture()),
        "disk": str(uuid.getnode()),
        "bios": platform.version(),
        "virtual": platform.machine().lower()
    }
    # 将字典转换为 JSON 字符串并编码为字节类型
    return json.dumps(info).encode()

    
def get_machine_id():
    sys = platform.system()
    if sys == 'Windows':
        #print("当前为Windows系统")
        return generate_device_id()
    elif sys == 'Linux':
        return generate_device_id()
    else:
        return generate_device_id()

def sha256(data):
    try:
        # 创建 SHA-256 哈希对象
        sha256 = hashlib.sha256()
        # 直接使用字节类型的数据更新哈希对象
        sha256.update(data)
        # 返回十六进制的哈希值
        return sha256.hexdigest()
    except Exception as e:
        print(f"Error sha256: {e}")
    return None

def decrypt_json_data(hiddenJson,pwd,flowCode,flowContentCode):
    try:
        if not pwd:
          raise Exception('授权码不能为空')
        machineCode = get_machine_id()
        if machineCode is None:
          raise Exception('解密失败——getmachineid')
        else:
          machineCode = sha256(machineCode)
        data = {
            "licenseCode": pwd,
            "machineCode": machineCode,
            "flowCode":flowCode,
            "flowContentCode":flowContentCode
        }
        url = service_host + "/workflow/workflow/decryptJsonData"
        response = requests.post(url, json=data)
        responseJson = response.json()
        if responseJson["code"] != 200:
          if responseJson["msg"]:
            print(responseJson["msg"])
          raise Exception("解密失败")
        return responseJson["data"]
    except Exception as e:
        raise Exception(e)

@PromptServer.instance.routes.post("/yxy/encipher")
async def encipher(request):
    try:
        json_data = await request.json()
        hiddenJson = json_data["hiddenJson"]
        tempJson = json_data["tempJson"]
        password = json_data["password"]
        workflowName = json_data["workflowName"]
        flowCode = json_data["flowCode"]
        tempJson = base64.b64encode(lzma.compress(tempJson.encode('utf-8'))).decode('utf-8')
        data = {
            "hiddenJson": hiddenJson,
            "tempJson": tempJson,
            "appKey": password,
            "workflowName": workflowName,
            "flowCode": flowCode
        }
        url = service_host + "/workflow/workflow/encipher"
        response = requests.post(url, json=data)
        responseJson = response.json()
        if responseJson["code"] != 200:
          if responseJson["msg"]:
            print(responseJson["msg"])
          raise Exception("加密失败")
        responseData = responseJson["data"]
        data={'msg':'加密成功','encryptText':responseData["encryptedText"],'flowCode':responseData["flowCode"],'flowContentCode':responseData["flowContentCode"],'success':True}
        return web.Response(text=json.dumps(data), content_type='application/json')
    except Exception as e:
        data={'msg':'加密处理异常','success':False}
        print(f"发生异常: {e}")
        traceback.print_exc()
        return web.Response(text=json.dumps(data), content_type='application/json')
  
@PromptServer.instance.routes.post("/yxy/appkey")
async def appkey(request):
    try:
        json_data = await request.json()
        password = json_data["password"]
        data = {
            "appKey": password
        }
        url = service_host + "/workflow/workflow/appKey"
        response = requests.post(url, json=data)
        responseJson = response.json()
        if responseJson["code"] != 200:
          if responseJson["msg"]:
            print(responseJson["msg"])
          raise Exception('加密处理异常')
        data={'msg':'验证成功','success':True}
        return web.Response(text=json.dumps(data), content_type='application/json')
    except Exception as e:
        data={'msg':'加密处理异常','success':False}
        print(f"发生异常: {e}")
        traceback.print_exc()
        return web.Response(text=json.dumps(data), content_type='application/json')

SIGIN_CODE_OBJ={}

class YxyEncryptNodes():
    def __init__(self):
        pass

    @classmethod
    def INPUT_TYPES(s):
        return {
                "required":{
                    "pwd": ("STRING",{"default": ""}),
                    "hiddenJson": ("STRING", {"default": ""}),
                    "flowCode": ("STRING", {"default": ""}),
                    "flowContentCode": ("STRING", {"default": ""})
                },
                "hidden": {
                    "kwargsObj": ("OBJECT", {"default": {}})
                }
              }

    RETURN_TYPES = AlwaysTupleZero(AlwaysEqualProxy("*"),)

    FUNCTION = "hidden_nodes"

    OUTPUT_NODE = False

    CATEGORY = "yxy"

    def hidden_nodes(self,pwd: str,hiddenJson: str,flowCode: str,flowContentCode: str,kwargsObj={},**kwargs):
        if hiddenJson[:32] in SIGIN_CODE_OBJ:
            obtainAuth=SIGIN_CODE_OBJ[hiddenJson[:32]]
            nnoutput=json.loads(decrypt_json_data(hiddenJson,obtainAuth,flowCode,flowContentCode))
        else:
            nnoutput=json.loads(decrypt_json_data(hiddenJson,pwd,flowCode,flowContentCode))
        idDNode={}
        graph = GraphBuilder()
        def get_node_result(nodeData,id):
            inputKeys=[nodeData['inputs'][ikey][0] for ikey in  list(nodeData['inputs'].keys()) if is_link(nodeData['inputs'][ikey]) and 'hidden' != nodeData['inputs'][ikey][0] and nodeData['inputs'][ikey][0] not in idDNode]
            for ikey in inputKeys:
                if ikey not in nnoutput:
                    continue
                node=get_node_result(nnoutput[ikey],ikey)
                idDNode[ikey]=node
            inputs=nodeData['inputs']
            newInputs={}
            for ikey in inputs.keys():
                if is_link(inputs[ikey]):
                    if inputs[ikey][0]=='hidden':
                        if inputs[ikey][1] in kwargs:
                            newInputs[ikey]=kwargs[inputs[ikey][1]]
                        elif inputs[ikey][1] in kwargsObj:
                            newInputs[ikey]=kwargsObj[inputs[ikey][1]]
                    elif inputs[ikey][0] in idDNode:
                        newInputs[ikey]=idDNode[inputs[ikey][0]].out(inputs[ikey][1])
                else:
                    newInputs[ikey]=inputs[ikey]
            if 'YxyEncryptNodes' == nodeData['class_type']:
                #newInputs['pwd']=pwd
                return graph.node(nodeData['class_type'],id,kwargsObj=newInputs,**newInputs)
            return graph.node(nodeData['class_type'],id,**newInputs)
        values = [value for key in nnoutput.keys() for value in nnoutput[key]['outputs']]
        for key in nnoutput.keys():
            nodeData=nnoutput[key]
            if len(nodeData['outputs'])>0:
                node=get_node_result(nodeData,key)
            for i in nodeData['outputs']:
                values[i[0]]=node.out(i[1])

        return {
                "result": tuple(values),
                "expand": graph.finalize(),
            }

NODE_CLASS_MAPPINGS = {
    "YxyEncryptNodes": YxyEncryptNodes
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "YxyEncryptNodes": "encrypt-node-yxy"
}
file_directory = os.path.dirname(os.path.abspath(__file__))
WEB_DIRECTORY=file_directory+"/js"